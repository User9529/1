import pandas as pd
import matplotlib.pyplot as plt
from tkinter import Tk, filedialog, messagebox
import seaborn as sns
import jieba
from wordcloud import WordCloud
import chardet
import warnings
import sys

warnings.filterwarnings('ignore')
# --------------------------
# 编码检测函数
# --------------------------
def detect_encoding(file_path):
    """自动检测文件编码"""
    with open(file_path, 'rb') as f:
        rawdata = f.read(10000)  # 读取前10000字节用于检测编码
        result = chardet.detect(rawdata)
        return result.get('encoding', 'utf-8')  # 默认使用utf-8，即使encoding为None

# --------------------------
# 文件选择功能
# --------------------------
def select_wechat_file():
    """选择微信账单文件并返回文件路径"""
    root = Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(
        title="选择微信支付账单CSV文件",
        filetypes=[("CSV文件", "*.csv"), ("所有文件", "*.*")]
    )
    root.destroy()
    return file_path

# --------------------------
# 数据预处理模块
# --------------------------
def preprocess_data(df):
    """已修复预处理逻辑"""
    try:
        # 列名规范化
        df.columns = df.columns.str.replace(r'[^\w\u4e00-\u9fa5]', '', regex=True)
        
        # 字段重命名 (兼容微信账单格式变化)
        df = df.rename(columns={
            '收/支': '收支',
            '金额(元)': '金额元',
            '当前状态': '状态',
            '交易类型': '类型'
        }, errors='ignore')

        # 金额处理 
        # (1) 清洗金额字符串
        df['金额'] = df['金额元'].str.replace(r'[^\d.-]', '', regex=True)  
        df['金额'] = pd.to_numeric(df['金额'], errors='coerce').fillna(0)  
        
        # (2) 支出标记为负，收入为正
        df['金额'] = df.apply(
            lambda x: -abs(x['金额']) if str(x.get('收支','')).strip() == '支出' else abs(x['金额']),
            axis=1
        )
        
        # (3) 处理退款逻辑 (行级处理避免Series判断)
        df['金额'] = df.apply(
            lambda x: abs(x['金额']) if '退款' in str(x.get('状态','')) else x['金额'],
            axis=1
        )

        #  必要字段校验
        required_cols = ['交易时间', '收支', '金额元']
        if missing := [c for c in required_cols if c not in df.columns]:
            raise ValueError(f"缺少必要字段: {', '.join(missing)}")

        #  时间特征处理 
        df['交易时间'] = pd.to_datetime(df['交易时间'], errors='coerce')
        df = df.dropna(subset=['交易时间'])
        df['日期'] = df['交易时间'].dt.date
        df['星期'] = df['交易时间'].dt.day_name(locale='zh_CN')
        df['小时段'] = pd.cut(
            df['交易时间'].dt.hour,
            bins=[0,6,9,12,14,17,20,24],
            labels=['深夜','早高峰','上午','午间','下午','晚高峰','夜间'],
            ordered=False
        )
        
        return df

    except Exception as e:
        messagebox.showerror("预处理失败", f"数据清洗异常: {str(e)}")
        raise

# --------------------------
# 智能分类模块
# --------------------------
def auto_categorize(row):
    """"基于交易描述智能分类"""
    desc = f"{str(row.get('商品', ''))} {str(row.get('交易对方', ''))}".lower()  # 处理空值
    category_rules = {
        '餐饮': ['餐饮', '餐厅', '咖啡', '奶茶', '饭', '面包', '火锅', '烧烤', '小吃', '外卖', 
               '麻辣烫', '蜜雪冰城', '包子', '夜包子', '汉堡', '饸烙面', '自选餐', '土菜馆'],
        '购物': ['商城', '超市', '网购', '便利店', '百货', '旗舰店', '天猫', '京东', '拼多多', 
               '零食', '赵一鸣', '购物中心', '三色鸽', '千千购物'],
        '交通': ['出行', '地铁', '公交', '打车', '加油', '停车', '充电', 'ETC', '高德', '滴滴', 
               '哈啰', '12306', '汽车票', '助力车', '铁旅科技'],
        '娱乐': ['电影', 'ktv', '游戏', '游乐', '演唱会', '演出', '门票', 'steam', '台球', '网咖'],
        '生活缴费': ['水电', '话费', '燃气', '物业', '房租', '缴费', '还款', '信用卡', '充值', '提现',
                 '联通', '考试费', '打印', '财政局'],
        '健康医疗': ['医院', '药房', '诊所', '体检', '医保', '药店', '健康', '美容美发', '西维美容'],
        '学习提升': ['书店', '课程', '培训', '教育', '电子书', '知识付费', '博物院'],
        '转账红包': ['转账', '红包', '收款', '群收款', '亲属卡', '微信红包']
    }
    
    for category, keywords in category_rules.items():
        if any(keyword in desc for keyword in keywords):
            return category
    return '其他'

# --------------------------
# 分析报告生成模块
# --------------------------
def generate_report(df):
    """生成分析报告数据"""
    # ---------- 新增调试步骤 ----------
    print("\n=== 支出数据调试 ===")
    print("收支列唯一值:", df['收支'].unique())
    print("金额描述统计:")
    print(df['金额'].describe())
    
    #正确筛选条件（兼容可能存在的空格）
    expense_mask = (
        df['收支'].str.strip().eq('支出') &  # 排除尾部空格
        (df['金额'] < 0)   # 支出应为负数
    )
    # 保存临时数据查看
    debug_df = df[expense_mask].copy()
    print("符合条件的记录样例:", debug_df[['收支','金额']].head(5))
    
    if debug_df.empty:
        messagebox.showwarning("分析提示", "有效筛选条件未匹配到任何数据，请检查金额符号规则")
        return None, ""
    
    report = {}
    
    # 确保'分类'列存在，如果不存在则创建
    if '分类' not in df.columns:
        df['分类'] = df.apply(auto_categorize, axis=1)
    
    # 筛选支出数据  
    expense_df = df[expense_mask].copy()
    print("\n===支出数据筛选验证===")
    expense_df['是否支出'] = expense_df['收支'].str.strip() == '支出'  # 处理空格问题
    expense_df['金额是否负'] = expense_df['金额'] < 0
    print("满足支出条件的数据量:", expense_df['是否支出'].sum())
    print("负金额数据量:", expense_df['金额是否负'].sum())
    
    if expense_df.empty:
        messagebox.showwarning("分析提示", "所选时间段内没有有效支出记录")
        return None, ""
    
    # 计算总支出、交易次数和日均消费
    report['总支出'] = abs(expense_df['金额']).sum()
    report['交易次数'] = len(expense_df)
    report['日均消费'] = report['总支出'] / expense_df['日期'].nunique()
    
    # 消费结构分析
    report['消费分类'] = expense_df.groupby('分类').agg(
        总金额=('金额', lambda x: abs(x).sum()),  # 改为绝对值求和
        笔数=('金额', 'count')
    )
    report['星期模式'] = expense_df.groupby('星期')['金额'].sum()
    
    # ====== 时空分析比例计算 ======
    # 时段分析 (绝对值求和)
    report['时段分析'] = expense_df.groupby('小时段')['金额'].agg(lambda x: abs(x.sum()))
    
    # 计算各时段消费比例（含深夜）
    total_expense = report['总支出']
    time_segments = ['深夜', '早高峰', '上午', '午间', '下午', '晚高峰', '夜间']
    report['时段比例'] = {seg: report['时段分析'].get(seg, 0) / total_expense for seg in time_segments}
    
    # 词云数据
    text_corpus = ' '.join(expense_df['商品'].fillna('') + ' ' + expense_df['交易对方'].fillna(''))
    wordcloud_text = ' '.join(jieba.cut(text_corpus))
    stopwords = {'收款方备注', '二维码收款', '美团App', '微信支付账单明细', 'None'}
    wordcloud_text = ' '.join([word for word in jieba.cut(text_corpus) if len(word) > 1 and word not in stopwords])
    
    return report, wordcloud_text
# --------------------------
# 消费建议生成模块
# --------------------------
def generate_advice(report):
    """根据分析结果生成个性化建议"""
    advice = []
    
    # 基础消费分析
    if report['总支出'] > 5000:
        advice.append("本月消费较高（¥%.2f），建议查看详细分类控制开支" % report['总支出'])
    elif report['总支出'] < 1500:
        advice.append("本月消费控制良好（¥%.2f），继续保持理性消费习惯" % report['总支出'])
        
    # 分类消费建议
    if not report['消费分类']['总金额'].empty:  # 修复列名
        top_category = report['消费分类']['总金额'].idxmax()
        if top_category == '餐饮' and report['消费分类']['总金额'][top_category] > 2000:
            advice.append(f"餐饮支出较高（¥{report['消费分类']['总金额'][top_category]:.2f}），建议减少外卖频率")
        elif top_category == '购物' and report['消费分类']['总金额'][top_category] > 1500:
            advice.append(f"购物消费占比较大（¥{report['消费分类']['总金额'][top_category]:.2f}），建议区分必要与非必要支出")
    else:
        advice.append("未识别到有效消费分类")
    
    # 消费时间建议 
    # 防御性获取数据（避免KeyError）
    time_ratio = report.get('时段比例', {})
    night_ratio = time_ratio.get('深夜', 0)
    if night_ratio > 0.15:
        advice.append(f"深夜消费占比较重（{night_ratio*100:.1f}%%），注意冲动消费")
        
    # 晚高峰对比早高峰（避免除零错误）
    morning = report['时段分析'].get('早高峰', 1)  # 默认1元避免ZeroDivision
    evening = report['时段分析'].get('晚高峰', 0)
    if evening > 2 * max(morning, 1):  # 至少1元作为基准
        advice.append(f"晚高峰消费高达早高峰的{evening/morning:.1f}倍，建议错峰消费")
    
    # 补充默认建议
    if not advice:
        advice = ["消费模式健康，继续保持当前的消费习惯！"]
    elif len(advice) < 3:
        advice.append("建议使用账单分类筛选功能，查看具体消费明细")
    
    return advice[:3]  # 返回最多三条建议


# --------------------------
# 可视化模块
# --------------------------
def visualize(report, title, wordcloud_text='', advice=[]):
    """生成可视化图表（含消费建议）"""
    try:
        #  校验核心数据必须字段 
        required_keys = ['总支出', '消费分类', '时段分析', '星期模式']
        if not all(key in report for key in required_keys):
            messagebox.showerror("数据异常", "分析报告不完整，无法生成图表")
            return

        plt.figure(figsize=(18, 16))
        plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 统一中文字体
        plt.rcParams['axes.unicode_minus'] = False
        plt.suptitle(title, y=1.0, fontsize=16)  # 提升主标题位置

        # ========== 使用GridSpec创建灵活布局 ==========
        gs = plt.GridSpec(3, 2, height_ratios=[2, 2, 1], hspace=0.4, wspace=0.3)

        # (1) 消费分类饼图
        ax1 = plt.subplot(gs[0, 0])
        report['消费分类']['总金额'].plot.pie(
            autopct=lambda p: f'{p:.1f}%\n¥{p*report["总支出"]/100:.2f}',
            startangle=90,
            wedgeprops={'linewidth': 1, 'edgecolor': 'white'}
        )
        ax1.set_title('消费分类占比', pad=15)

        # (2) 时段分析柱状图
        ax2 = plt.subplot(gs[0, 1])
        sns.barplot(
            x=report['时段分析'].index,
            y=report['时段分析'].values,
            palette="viridis"
        )
        ax2.set_title('分时段消费分析', pad=15)
        ax2.set_ylabel('消费金额（元）')
        plt.sca(ax2)
        plt.xticks(rotation=15)

        # (3) 词云模块
        ax3 = plt.subplot(gs[1, 0])
        if len(wordcloud_text.strip()) > 0:
            try:
                wordcloud = WordCloud(
                    font_path='msyh.ttc',
                    width=800,
                    height=600,
                    background_color='white'
                ).generate(wordcloud_text)
                ax3.imshow(wordcloud)
                ax3.set_title('消费关键词云', pad=15)
            except:
                pass
        ax3.axis("off")

        # (4) 周消费趋势图
        ax4 = plt.subplot(gs[1, 1])
        if not report['星期模式'].empty:
            sns.lineplot(
                data=report['星期模式'],
                marker='o',
                markersize=8
            )
            ax4.set_xticks(range(7))
            ax4.set_xticklabels(['周一','周二','周三','周四','周五','周六','周日'])
        ax4.set_title('周消费趋势', pad=15)
        ax4.grid(True, alpha=0.3)

        # (5) 消费建议面板
        ax5 = plt.subplot(gs[2, :])
        ax5.axis('off')
        advice_text = "💡 消费建议：\n\n" + '\n\n'.join(f"• {tip}" for tip in advice)
        ax5.text(
            0.05, 0.5,
            advice_text,
            va='center',
            ha='left',
            fontsize=12,
            linespacing=1.8,
            bbox=dict(boxstyle="round", 
                     facecolor='#f8f9fa', 
                     edgecolor='#dee2e6',
                     pad=0.8)
        )

        plt.tight_layout()
        plt.show()

    except Exception as e:
        messagebox.showerror("可视化错误", f"图表生成失败: {str(e)}")
        plt.close()
# --------------------------
# 主程序逻辑
# --------------------------
def main():
    try:
        # 文件选择
        file_path = select_wechat_file()
        if not file_path:
            print("操作已取消")
            return

        # 检测编码
        encoding = detect_encoding(file_path)
        
        skiprows = 0
        header_found = False
        
        # ========改进列头检测逻辑 ========
        expected_columns = {'交易时间', '交易类型', '交易对方', '商品', '收/支', '金额(元)'}
        
        with open(file_path, 'r', encoding=encoding) as f:
            for i, line in enumerate(f):
                # 清洗列头行（兼容中文符号和空格）
                clean_line = line.strip().replace(' ', '').replace('\ufeff', '')
                
                #  判断是否包含所有关键字段（即使顺序不同）
                if all(col in clean_line for col in expected_columns):
                    skiprows = i
                    header_found = True
                    print(f"[DEBUG] 找到表头行：第 {i+1} 行 | 内容: {clean_line}")  # 调试信息
                    break
            else:
                # 未找到表头的详细错误提示
                error_msg = "无法识别有效的数据列头！\n表头应包含以下字段: " + ", ".join(expected_columns)
                messagebox.showerror("格式错误", error_msg)
                return  # 直接退出，不再继续执行
        
        # ======== 改进CSV读取参数 ========
        # 微信账单通常使用制表符分隔且无引号处理
        df = pd.read_csv(
            file_path,
            skiprows=skiprows,
            encoding=encoding,
            sep=',',          # 逗号分隔符（重要）
            quotechar='"',    # 正确处理字段内引号
            engine='python',
            on_bad_lines='warn'
        )

        # ======== 后续原有逻辑不变 ========
        df = preprocess_data(df)
        print("预处理后列名:", df.columns.tolist())  # 调试信息
        df['分类'] = df.apply(auto_categorize, axis=1)
        
        # 生成报告和可视化（其余代码不变）
        report, wordcloud_text = generate_report(df)
        if report is None:
            messagebox.showwarning("分析终止", "没有可分析的支出数据")
            return
        
        advice = generate_advice(report)
        title = f"微信支付账单分析报告\n{df['日期'].min()} 至 {df['日期'].max()}"
        
        # 输出分析结果
        print("\n" + "="*40)
        print(title)
        print(f"📅 分析周期：{df['日期'].min()} 至 {df['日期'].max()}")
        print(f"💵 总支出：¥{report['总支出']:.2f}")
        print(f"🛒 日均消费：¥{report['日均消费']:.2f}")
        print("\n🏷️ 消费分类TOP3：")
        print(report['消费分类']['总金额'].sort_values(ascending=False).head(3))
        
        print("\n💡 个性化建议：")
        for i, tip in enumerate(advice, 1):
            print(f"{i}. {tip}")
        
        visualize(report, title, wordcloud_text, advice)  # 确保传入第三个参数
        
    except pd.errors.ParserError as e:
        messagebox.showerror("文件解析错误", f"CSV文件解析失败，请确认文件完整性\n错误详情：{str(e)}")
    except KeyError as e:
        messagebox.showerror("字段错误", f"缺少必要字段：{str(e)}，请确认使用的是微信官方导出的账单")
    except Exception as e:
        messagebox.showerror("运行时错误", f"程序运行异常：{str(e)}")
    finally:
        input("\n按回车键退出...")

if __name__ == "__main__":
    main()